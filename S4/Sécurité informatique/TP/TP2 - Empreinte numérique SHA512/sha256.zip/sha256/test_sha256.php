<?php

// Fonction de base de PHP
echo hash('sha256', '01234567879');
echo("\n");

// Fonction de base de PHP
echo hash('sha256', '0123456787901234567879012345678790123456787901234567879');
echo("\n");

?>