%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PASSE BAS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function ex3_6

close all
clear
clc

global parametres xWin hWin yWin XWin HWin YWin xLoaded flim  bouton_play


COLOR1 = [0.52 0.75 1];
COLOR2 = [0.52 0.75 1];
COLOR3 = [1 0 0];

xLoaded = false;

figure(1)
set(gcf,...
    'Units','pixels',...
    'Position',[50 50 800 600],...
    'Resize','off',...
    'ToolBar','figure',...
    'color',COLOR1,...
    'numbertitle','off',...
    'name','L2 SPI - TP Traitement du signal'...
    );



xWin = axes(...
    'Units','pixels',...
    'Position',[50 450 300 130],...
    'Box','on'...
    );

XWin = axes(...
    'Units','pixels',...
    'Position',[450 450 300 130],...
    'Box','on'...
    );


hWin = axes(...
    'Units','pixels',...
    'Position',[50 280 300 130],...
    'Box','on'...
    );


HWin = axes(...
    'Units','pixels',...
    'Position',[450 280 300 130],...
    'Box','on'...
    );

yWin = axes(...
    'Units','pixels',...
    'Position',[50 110 300 130],...
    'Box','on'...
    );

YWin = axes(...
    'Units','pixels',...
    'Position',[450 110 300 130],...
    'Box','on'...
    );





uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[500 10 80 20],...
    'string','alpha = ',...
    'fontsize',10,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);
parametres(1)=uicontrol('style','edit' , ...
    'units','pixels', ...
    'position',[580 10 100 20],...
    'string','200*2*pi',...
    'fontsize',10,...
    'backgroundcolor',[1 1 1],...
    'CallBack',@MaJ);


bouton_new = uicontrol('Style', 'pushbutton', 'String', 'Charger x(t)',...
    'Position', [20 50 300 20],...
    'Callback', @LoadSignals);

bouton_play(1) = uicontrol('Style', 'pushbutton', 'String', 'PLAY x(t)',...
    'Position', [20 20 100 20],...
    'Callback', @PlaySignal);
bouton_play(2) = uicontrol('Style', 'pushbutton', 'String', 'PLAY h(t)',...
    'Position', [130 20 100 20],...
    'Callback', @PlaySignal);
bouton_play(3) = uicontrol('Style', 'pushbutton', 'String', 'PLAY x(t)*h(t)',...
    'Position', [240 20 150 20],...
    'Callback', @PlaySignal);


flim = [-10 10];

axes(xWin)
xlabel('t (s)')
ylabel('x (t)')

axes(XWin)
ylabel('|X| (dB)')
xlabel('f (kHz)')
xlim(flim)

axes(hWin)
xlabel('t (s)')
ylabel('h (t)')

axes(HWin)
ylabel('|H| (dB)')
xlabel('f (kHz)')
xlim(flim)

axes(yWin)
xlabel('t (s)')
ylabel('y (t)')

axes(YWin)
ylabel('|Y| (dB)')
xlabel('f (kHz)')
xlim(flim)

MaJ(1,1)

end










function MaJ(obj,event)

global parametres xWin hWin yWin XWin HWin YWin xLoaded flim
global t x Freq X h N Nfft Fe y

if obj==parametres(1) || obj==1 % ne refaire les calculs que si on change T
    alpha = str2num(get(parametres(1),'string'))
    
    
    % Definition du signal %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Fe = 44100;
    dt = 1/Fe;
    
    if ~xLoaded % si le x n'a pas encore ete charge
        t = [0:1:fix(0.05/dt)]*dt;
        Nfft = pow2(nextpow2(length(t)));
        t = t(:);
    end
    
    
    
    h = zeros(size(t));
    
    h(t<0) = 0;
    h(t>=0) = exp(-alpha*(t(t>=0)));
    
    
    
    H = fft(h,Nfft);
    
    
    if xLoaded
        Y=X.*H;
        y=real(ifft(Y,Nfft));
        y=y(1:N);
    end
    
    
end




if xLoaded
    
    axes(xWin)
    plot(t,x,'Linewidth',2)
    xlabel('t (s)')
    ylabel('x(t)')
    xlim([0 t(end)])
    
    axes(XWin)
    plot([-Nfft/2:Nfft/2-1]/Nfft*Fe*1E-3,20*log10(abs(fftshift(X))),'Linewidth',2)
    ylabel('|X| (dB)')
    xlabel('f (kHz)')
    xlim(flim)
    
    axes(yWin)
    plot(t,y,'Linewidth',2)
    xlabel('t (s)')
    ylabel('y(t)')
    xlim([0 t(end)])
    
    axes(YWin)
    plot([-Nfft/2:Nfft/2-1]/Nfft*Fe*1E-3,20*log10(abs(fftshift(Y))),'Linewidth',2)
    ylabel('|Y| (dB)')
    xlabel('f (kHz)')
    xlim(flim)
    
    
end


axes(hWin)
plot(t,h,'Linewidth',2)
xlabel('t (s)')
ylabel('h (t)')
xlim([0 0.05])

axes(HWin)
plot([-Nfft/2:Nfft/2-1]/Nfft*Fe*1E-3,20*log10(abs(fftshift(H))),'Linewidth',2)
ylabel('|H| (dB)')
xlabel('f (kHz)')
xlim(flim)




end





function LoadSignals(obj,event)


global parametres xWin hWin yWin XWin HWin YWin xLoaded
global t x Freq X h N Nfft Fe

[FileName,PathName] = uigetfile('*.wav','Choisir le signal x(t)');
[x fs] = wavread([PathName FileName]);
x = x(:,1);
dt = 1/fs;

N = length(x);
t = [0:N-1]*dt;
t = t(:);


Nfft = pow2(nextpow2(N));

X = fft(x,Nfft);




xLoaded = true;


MaJ(1,1)

end






function PlaySignal(obj,event)

global parametres xWin hWin yWin XWin HWin YWin xLoaded bouton_play
global t x Freq X h N Nfft Fe y


switch obj
    case bouton_play(1)
        if xLoaded
            sound(x/max(abs(x)),Fe);
        end
    case bouton_play(2)
        sound(h/max(abs(h)),Fe);
    case bouton_play(3)
        if xLoaded
            sound(y/max(abs(y)),Fe);
        end
end

end






