%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FENETRE EXPONENTIELLE DECROISSANTE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function ex3_1

clear;close all;clc

global parametres timeWin fourierTopWin fourierBottomWin


COLOR1 = [0.52 0.75 1];
COLOR2 = [0.52 0.75 1];


figure(1)
set(gcf,...
    'Units','pixels',...
    'Position',[50 50 1000 500],...
    'Resize','off',...
    'ToolBar','figure',...
    'color',COLOR1,...
    'numbertitle','off',...
    'name','EX. 23'...
    );

uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[50 450 800 25],...
    'string','Transform�e de Fourier d''une fen�tre exponentielle',...
    'fontsize',16,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);

timeWin = axes(...
    'Units','pixels',...
    'Position',[50 50 400 250],...
    'Box','on'...
    );

fourierTopWin = axes(...
    'Units','pixels',...
    'Position',[550 250 400 150],...
    'Box','on'...
    );
xlabel('f (Hz)')

fourierBottomWin = axes(...
    'Units','pixels',...
    'Position',[550 50 400 150],...
    'Box','on'...
    );
xlabel('f (Hz)')


uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[50 320 80 20],...
    'string','alpha = ',...
    'fontsize',10,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);
parametres(1)=uicontrol('style','edit' , ...
    'units','pixels', ...
    'position',[130 320 100 20],...
    'string','100',...
    'fontsize',10,...
    'backgroundcolor',[1 1 1],...
    'CallBack',@MaJ);




parametres(101)=uicontrol('style','radiobutton' , ...
    'units','pixels', ...
    'position',[360 380 20 20],...
    'backgroundcolor',COLOR1,...
    'value',1,...
    'CallBack',@selectFourierAspect);
uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[380 380 80 20],...
    'string',' mag/phase',...
    'fontsize',10,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);

parametres(102)=uicontrol('style','radiobutton' , ...
    'units','pixels', ...
    'position',[360 350 20 20],...
    'backgroundcolor',COLOR1,...
    'value',0,...
    'CallBack',@selectFourierAspect);
uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[380 350 80 20],...
    'string',' real/imag',...
    'fontsize',10,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);


parametres(201)=uicontrol('style','checkbox' , ...
    'units','pixels', ...
    'position',[600 410 20 20],...
    'backgroundcolor',COLOR1,...
    'value',0,...
    'CallBack',@selectFourierAspect);
uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[620 410 80 20],...
    'string',' log x-axis',...
    'fontsize',10,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);


parametres(202)=uicontrol('style','checkbox' , ...
    'units','pixels', ...
    'position',[710 410 20 20],...
    'backgroundcolor',COLOR1,...
    'value',0,...
    'CallBack',@selectFourierAspect);
uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[730 410 80 20],...
    'string',' mag dB',...
    'fontsize',10,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);

parametres(203)=uicontrol('style','checkbox' , ...
    'units','pixels', ...
    'position',[820 410 20 20],...
    'backgroundcolor',COLOR1,...
    'value',0,...
    'CallBack',@selectFourierAspect);
uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[840 410 100 20],...
    'string',' phase d�roul�e',...
    'fontsize',10,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);


MaJ(1,0)

end





function MaJ(obj,event)

global parametres timeWin fourierTopWin fourierBottomWin
global t x Freq X

if obj==parametres(1) || obj==1 % ne refaire les calculs que si on change un param�tre
    alpha = str2num(get(parametres(1),'string'))
    
    
    % Definition du signal %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %     Te = 1/alpha/100;
    %     Te = 10/alpha*0.001;
    %     N = fix(10/alpha/Te);
    %     t = (-10:N-1)*Te;
    %     x = zeros(1,N+10);
    %     x(11:N+10) = exp(-alpha*t(11:N+10));
    %     Freq =-100:0.01:100-0.01; % frequency axis
    %     X = 1./(alpha+j*2*pi*Freq);
    
    
    dt = 1E-5; % contr�le la finesse de l'affichage (en temps mais aussi en freq)
    t = [fix(-0.1/dt):1:fix(0.5/dt)]*dt;
    x = zeros(size(t));
    Freq = linspace(-100,100,length(t)); % frequency axis
    
    x(t<0) = 0;
    x(t>=0) = exp(-alpha*(t(t>=0)));
    
    X = 1./(alpha+j*2*pi*Freq);
    
end



% Affichage x(t) et X(f) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

axes(timeWin)
plot(t,x,'Linewidth',2)
ylabel('x(t)')
xlabel('t (s)')
grid on
xlim([t(1) t(end)])
ylim([min([0 1.1*min(x)]) 1.1*max(x)])

if get(parametres(201),'value')==1 % pour log x, uniquement freqs positives
    select = Freq>0;
    Freq1 = Freq(select);
    Freq1 = Freq1(1);
else
    select = Freq==Freq;
end

if get(parametres(101),'value')==1 % mag/phase
    
    axes(fourierTopWin)
    
    if get(parametres(202),'value')==1 % mag dB ?
        plot(Freq(select),20*log10(abs(X(select))),'Linewidth',2)
        ylabel('|X(f)| (dB)')
        ylim([-50 0]+max(20*log10(abs(X(select))))+3) % modifier la dynamique ici
    else
        plot(Freq(select),abs(X(select)),'Linewidth',2)
        ylabel('|X(f)|')
        ylim([min([0 1.1*min(real(X))]) 1.1*max(abs(X))])
    end
    grid on
    xlabel('f (Hz)');
    
    
    if get(parametres(201),'value')==1 % log x ?
        set(gca,'XScale','log')
        xlim([Freq1 Freq(end)])
    else
        xlim([Freq(1) Freq(end)])
    end
    
    axes(fourierBottomWin)
    if get(parametres(203),'value')==1
        plot(Freq(select),unwrap(angle(X(select))),'Linewidth',2)
    else
        plot(Freq(select),angle(X(select)),'Linewidth',2)
        ylim([-1 1]*1.1*pi)
    end
    grid on
    xlabel('f (Hz)');
    ylabel('\theta_X(f)')
    
    
    if get(parametres(201),'value')==1
        set(gca,'XScale','log')
        xlim([Freq1 Freq(end)])
    else
        xlim([Freq(1) Freq(end)])
    end
    
else % real/imag
    
    axes(fourierTopWin)
    plot(Freq(select),real(X(select)),'Linewidth',2)
    grid on
    xlabel('f (Hz)')
    ylabel('Re[X(f)]')
    
    if get(parametres(201),'value')==1  % log x ?
        set(gca,'XScale','log')
        xlim([Freq1 Freq(end)])
    else
        xlim([Freq(1) Freq(end)])
    end
    
    ylim([min([0 1.1*min(real(X))]) 1.1*max(real(X))])
    
    axes(fourierBottomWin)
    plot(Freq(select),imag(X(select)),'Linewidth',2)
    grid on
    xlabel('f (Hz)')
    ylabel('Im[X(f)]')
    
    if get(parametres(201),'value')==1
        set(gca,'XScale','log')
        xlim([Freq1 Freq(end)])
    else
        xlim([Freq(1) Freq(end)])
    end
    
    
    if ~isempty(find(imag(X)~=0))
        ylim([min([0 1.1*min(imag(X))]) 1.1*max(imag(X))])
    else
        ylim([-1 1])
    end
    
end


end




function selectFourierAspect(obj,event)

global parametres timeWin fourierTopWin fourierBottomWin

if obj==parametres(101) % mag/phase
    set(parametres(101),'value',1);
    set(parametres(102),'value',0);
    
    set(parametres(202),'enable','on')
    set(parametres(203),'enable','on')
    
elseif obj==parametres(102) % real/imag
    set(parametres(101),'value',0);
    set(parametres(102),'value',1);
    
    set(parametres(202),'value',0)
    set(parametres(202),'enable','inactive')
    
    set(parametres(203),'value',0)
    set(parametres(203),'enable','inactive')
    
end

MaJ(0,0)

end


