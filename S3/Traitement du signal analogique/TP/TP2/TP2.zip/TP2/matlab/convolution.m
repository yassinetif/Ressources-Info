%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              %
%         CONVOLUTION          %
%                              %
% entre 2 signaux              %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function convolution

close all
clear all
clc

global x h y fs

figure(1)
clf
set(gcf,'Units','pixels')
set(gcf,'Position',[50 50 500 500])
%subplot(211)

fenetre(1) = axes('Position',[0.1 0.75 0.85 0.2]);

fenetre(2) = axes('Position',[0.1 0.5 0.85 0.2]);

fenetre(3) = axes('Position',[0.1 0.25 0.85 0.2]);


bouton_new = uicontrol('Style', 'pushbutton', 'String', 'Nouvelle convolution...',...
    'Position', [20 50 300 20],...
    'Callback', @LoadSignals);
bouton_play(1) = uicontrol('Style', 'pushbutton', 'String', 'PLAY x(t)',...
    'Position', [20 20 100 20],...
    'Callback', @PlaySignal);
bouton_play(2) = uicontrol('Style', 'pushbutton', 'String', 'PLAY h(t)',...
    'Position', [130 20 100 20],...
    'Callback', @PlaySignal);
bouton_play(3) = uicontrol('Style', 'pushbutton', 'String', 'PLAY x(t)*h(t)',...
    'Position', [240 20 150 20],...
    'Callback', @PlaySignal);


    function PlaySignal(obj,event)
        switch obj
            case bouton_play(1)
                    sound(x/max(abs(x)),fs);
            case bouton_play(2)
                    sound(h/max(abs(h)),fs);
            case bouton_play(3)
                    sound(y/max(abs(y)),fs);
        end
        
    end

    function LoadSignals(obj,event)
        
        [FileName,PathName] = uigetfile('*.wav','Choisir le signal x(t)');
        [x fs] = wavread([PathName FileName]);
        x = x(:,1);
        dt = 1/fs;
        N = length(x);
        t = [0:N-1]*dt;
        axes(fenetre(1))
        plot(t,x)
        ylabel('x(t)')
        xlim([0 t(end)])
        
        
        
        [FileName,PathName] = uigetfile('*.wav','Choisir le signal h(t)');
        [h fs_h] = wavread([PathName FileName]);
        h = h(:,1);
        axes(fenetre(2))
        plot([0:length(h)-1]*dt,h)
        ylabel('h(t)')
        xlim([0 t(end)])
        shg
        
        
        
        y = conv(x,h);
        y = y(1:N);
        axes(fenetre(3))
        plot(t,y)
        ylabel('y(t)')
        xlim([0 t(end)])
        
    end

end
