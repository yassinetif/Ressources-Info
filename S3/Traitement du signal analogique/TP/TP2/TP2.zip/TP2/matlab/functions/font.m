%Sets the font to times helvetica and size S.
%
%font(h,S);
%
%h=handle
%S=size

function font(h,S);

set(h,'fontname','helvetica');
set(h,'fontsize',S);