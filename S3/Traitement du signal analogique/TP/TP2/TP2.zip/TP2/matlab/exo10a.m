%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              %
%         EXERCISE 10a         %
%                              %
%   Syst�mes � temps continu   %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;close all;clc

% -------------------------------------------------------------------------- %
% Les param�tres pour g�n�rer les r�ponses impulsionnelles � "temps continu" %
%                       (� ne pas modifier SVP)                              %
% -------------------------------------------------------------------------- %

Fe_over = 2*44100;
T_tot = 4;
N_over = fix(T_tot*Fe_over);
t_over = (0:N_over-1)/Fe_over;

td = 0.5; % valeur arbitraire

disp('Vous devez choisir les param�tres suivants')
disp('------------------------------------------')
disp('|             t1 dans [1ms,1s]            |')
disp('|         alpha dans [0.001,0.99]         |')
disp('------------------------------------------')
disp('')
disp('')

t1 = input('t1 = (dans [1ms,1s]) ');
while ( (t1<1e-3) | (t1>1))
    disp('|             t1 dans [1ms,1s]            |')
    t1 = input('t1 = (dans [1ms,1s]) ');
end

alpha = input('alpha = (dans [0.001,0.99]) ');
while ( (alpha<1e-3) | (alpha>0.99))
    disp('|         alpha dans [0.001,0.99]         |')
    alpha = input('alpha = (dans [0.001,0.99]) ');
end

% ------------------------------ %
% r�ponse impulsionnelle directe %
% ------------------------------ %

hdirecte = zeros(1,N_over);
hdirecte(fix(td*Fe_over+1)) = 1;
hdirecte(fix((td+t1)*Fe_over+1)) = alpha;

% --------------- %
% signal d'entr�e %
% --------------- %

x = zeros(1,N_over);
Tx = 1;
F0x = 7.5/Tx;
Nx = fix(Tx*Fe_over);
w = tukeywin(Nx,0.25);
x(1:Nx) = (sin(2*pi*F0x*t_over(1:Nx))).*w.';

% ---------------- %
% signal de sortie %
% ---------------- %

y = zeros(1,N_over);

y(fix(td*Fe_over+1:td*Fe_over+Nx)) = x(1:Nx);
y(fix((td+t1)*Fe_over+1:(td+t1)*Fe_over+Nx)) = y(fix((td+t1)*Fe_over+1:(td+t1)*Fe_over+Nx)) + alpha*x(1:Nx);

% --------------------------------------------------------- %
% ligne � retard (r�ponse impulsionnelle du filtre inverse) %
% --------------------------------------------------------- %

hinverse = zeros(1,N_over);
hinverse(1:fix(t1*Fe_over):3*fix(t1*Fe_over)+1) = (-alpha).^(0:3);

% ---------------- %
% signal de sortie %
% ---------------- %

z = zeros(1,N_over);

z = z+y;
z(fix(t1*Fe_over+1):end) = z(fix(t1*Fe_over+1):end) - alpha*y(1:end-fix(t1*Fe_over));
z(fix(2*t1*Fe_over+1):end) = z(fix(2*t1*Fe_over+1):end) + alpha^2*y(1:end-fix(2*t1*Fe_over));
z(fix(3*t1*Fe_over+1):end) = z(fix(3*t1*Fe_over+1):end) - alpha^3*y(1:end-fix(3*t1*Fe_over));


% ------- %
% figures %
% ------- %

figure(1)
subplot(311)
plot(t_over,x)
grid on
ylabel('x(t)')
subplot(312)
plot(t_over,y)
grid on
ylabel('y(t)')
subplot(313)
plot(t_over,z)
xlabel('Time (s)')
ylabel('z(t)')
grid on



figure(2);
plot(t_over,hdirecte)
grid on
ylabel('h_4(t)')
xlabel('Time (s)')
axis([0 1.6 0 1.1]) 

