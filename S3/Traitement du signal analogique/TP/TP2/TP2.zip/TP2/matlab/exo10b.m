%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%
%                              %
%         EXERCISE 10b         %
%                              %
%   Syst�mes � temps continu   %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;close all;clc

% -------------------------------------------------------------------------- %
% Les param�tres pour g�n�rer les r�ponses impulsionnelles � "temps continu" %
%                       (� ne pas modifier SVP)                              %
% -------------------------------------------------------------------------- %

Fe_over = 44100;
T_tot = 3;
N_over = fix(T_tot*Fe_over);
t_over = (0:N_over-1)/Fe_over;



% fprintf('Choisissez un fichier son... ')
% 
% [FileName,PathName] = uigetfile('*.wav');
% 
% fprintf(FileName)
% fprintf('\n\n')
% 
% 
% [x Fe_over] = wavread([PathName FileName]);
% 
% x = x(:,1);
% N_over = length(x);
% t_over = (0:N_over-1)/Fe_over;


disp('Vous devez choisir le param�tres suivants')
disp('------------------------------------------')
disp('|         0 < R < 1                      |')
disp('|         2 < L < 20                     |')
disp('------------------------------------------')
disp('')
disp('')

R = input('R = (0 < R < 1) ');
while ( (R<0) | (R>1))
    disp('|         R (0 < R < 1)         |')
    R = input('R = (0 < R < 1) ');
end
L = input('L = (2 < L < 20 ) ');
while ( (L<2) | (L>20) )
    disp('|         2 < L < 20          |')
    L = input('l = (2 < L < 20 ) ');
end


MIC = [L/2 1.3*L-1 1.5];
N = 24;
%R = 0.95;
RM = [L 1.3*L 3];
SRC =[1 1 1];

hc = rir(Fe_over, MIC, N, R, RM, SRC);

% � ajouter : signal d'entr�e + figures + sauvegarde format wav + ...

figure(1)
clf
plot([0:length(hc)-1]*1/Fe_over,hc,'b','LineWidth',2)
grid on
ylabel('h(t)')
axis([-0.001 T_tot 1.1*min(hc) 1.1*max(hc)])


wavwrite(hc*0.95/max(hc),Fe_over,'exo10b_RI_simulee.wav')

%%

figure(10)
clf
hold on
vertices = [0 0 0; 0 RM(2) 0; RM(1) RM(2) 0; RM(1) 0 0; 0 0 RM(3); 0 RM(2) RM(3); RM(1) RM(2) RM(3); RM(1) 0 RM(3)];
faces = [1 2 3 4; 2 6 7 3; 4 3 7 8; 1 5 8 4; 1 2 6 5; 5 6 7 8];
plot3(SRC(1),SRC(2),SRC(3),'r*','MarkerSize',10,'DisplayName','source')
plot3(MIC(1),MIC(2),MIC(3),'bo','MarkerSize',10,'DisplayName','micro')
legend toggle
legend boxoff
patch('Vertices', vertices, 'Faces', faces, 'FaceColor', 'g','FaceAlpha',0.1);
xlabel('X')
ylabel('Y')
zlabel('Z')
view(60,30)
axis equal
xlim([0 RM(1)]+2*[-1 1])
ylim([0 RM(2)]+2*[-1 1])
zlim([0 RM(3)]+2*[0 1])


