%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              %
%         EXERCISE 9c          %
%                              %
% Convolutions � temps continu %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;close all;clc



disp('Vous devez choisir les param�tres dans les intervalles suivants ')
disp('----------------------------------------------------------------')
disp('|                  Tw (en seconde) dans [0.1ms,10ms]               |')
disp('----------------------------------------------------------------')
disp('')
disp('')


Tw = input('Tw = (en seconde) ');
while ( (Tw<0.0001) | (Tw>0.01))
    disp('|                  Tw dans [0.1ms,10ms]                   |')
    Tw = input('Tw = (en seconde) ');
end




% -------------------------------------------------------------------------- %
% Les param�tres pour g�n�rer les r�ponses impulsionnelles � "temps continu" %
%                       (� ne pas modifier SVP)                              %
% -------------------------------------------------------------------------- %

Fe_over = 2*44100;
T_tot = 2^17/Fe_over;
N_over = fix(T_tot*Fe_over);
t_over = (0:N_over-1)/Fe_over;

    


% ------------------------------------------------------------------ %
% Les param�tres pour g�n�rer les signaux d'entr�e � "temps continu" %
%                  (� ne pas modifier SVP)                           %
% ------------------------------------------------------------------ %

    % ----- %
    % xc(t) %
    % ----- %
    
    Fc = 100; 
	[B,A] = oct3dsgn(Fc,Fe_over); % 1/3 octave autour de 100Hz
    sc = filter(B,A,randn(1,N_over)); % bruit blanc filtr� dans la bande de 1/3 d'octave
    RSB = 10;
    Pb = std(sc)^2/(10^(RSB/10));
    bc = sqrt(Pb)*randn(1,N_over);
    xc = sc + bc;
    
    % ----- %
    % hc(t) %
    % ----- %

    hc = zeros(1,N_over);
    Th = Tw;
    Nh = fix(Th*Fe_over);
    hc(1:Nh) = ones(1,Nh);


% ---------------------------------- %
% les convolutions � "temps continu" %
% ---------------------------------- %

%yc = conv(xc,hc);
yc = (real(ifft(fft(xc).*fft(hc))));
yc = yc/Fe_over; % pour l'�quation aux dimensions

% 
% f = (0:N_over-1)*Fe_over/N_over;
% figure(10)
% clf
% Xc = fft(xc);
% Hc = fft(hc);
% Yc = fft(yc);
% subplot(211)
% hold on
% plot(f(1:N_over/2+1),20*log10(abs(Xc(1:N_over/2+1))),'LineWidth',2)
% plot(f(1:N_over/2+1),20*log10(abs(Hc(1:N_over/2+1))),'r','LineWidth',2)
% %plot(f(1:N_over/2+1),20*log10(abs(Yc(1:N_over/2+1))),'k--','LineWidth',2)
% xlim([0 1200])
% grid on
% subplot(212)
% hold on
% plot(f(1:N_over/2+1),angle(Xc(1:N_over/2+1)),'LineWidth',2)
% plot(f(1:N_over/2+1),angle(Hc(1:N_over/2+1)),'r','LineWidth',2)
% %plot(f(1:N_over/2+1),angle(Yc(1:N_over/2+1)),'k--','LineWidth',1)
% xlim([0 1200])
% grid on


% ------- %
% figures %
% ------- %

figure(1)
subplot(311)
hold off
plot(t_over,xc,'b','LineWidth',2)
grid on
ylabel('x_c(t)')
axis([-0.001 T_tot 1.1*min(xc) 1.1*max(xc)])
figure(1)
subplot(312)
hold off
plot(t_over,hc,'b','LineWidth',2)
grid on
ylabel('h_3(t)')
axis([-0.001 T_tot 0-0.1*max(hc) 1.1*max(hc)])
subplot(313)
hold off
plot(t_over,yc,'k','LineWidth',2)
grid on
ylabel('y_c(t)')
axis([-0.001 T_tot 1.1*min(yc) 1.1*max(yc)])
%axis([-0.1 T_tot -0.1 1.1])

wavwrite(xc*0.95/max(abs(xc)),Fe_over,'exo9c_xc.wav')
wavwrite(yc*0.95/max(abs(yc)),Fe_over,'exo9c_yc.wav')
