%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Synthese Fourier
%
% Construction d'un signal a partir des coefficients cn complexes
% (amplitude et phase)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function synthese_Fourier

clear all;
close all;

global handles N xN fs f0

N = 12;

% Cr�ation de l'objet Figure
handles(1)=figure('units','pixels',...
    'position',[50 50 800 320],...
    'color',[0.52 0.75 1],...
    'numbertitle','off',...
    'name','synthese de Fourier',...
    'menubar','none',...
    'resize','on');

for i=0:N
    rnames{i+1} = ['n = ' num2str(i)];
end

handles(2) = uitable('Data',zeros(N+1,2), ...
    'ColumnName',{'|c_n|','phi_n'},...
    'units','pixels', ...
    'Position',[10 10 260 300], ...
    'columnformat',{'numeric','numeric'}, ...
    'columneditable',logical([1,1]),...
    'ColumnWidth',{80,80},...
    'RowName',rnames,...
    'CellEditCallback',@Rafraichir);


handles(3)=uicontrol('style','pushbutton',...
    'units','pixels',...
    'position',[300 50 200 20],...
    'string','Rafraichir signal',...
    'fontsize',12, ...
    'callback',@Rafraichir);
handles(4)=uicontrol('style','pushbutton',...
    'units','pixels',...
    'position',[510 50 200 20],...
    'string','Ecouter signal',...
    'fontsize',12, ...
    'callback',@Ecouter);

handles(5)=uicontrol('style','edit' , ...
     'units','pixels', ...
    'position',[600 100 100 20],...
    'string','440',...
    'fontsize',10,...
    'backgroundcolor',[1 1 1]);
handles(51)=uicontrol('style','text' , ...
     'units','pixels', ...
    'position',[300 100 280 20],...
    'string','Freq. fondamentale (Hz)',...
    'fontsize',10,...
    'backgroundcolor',[0.52 0.75 1]);

handles(6)=axes('units','pixels',...
    'position',[320 200 470 110]);

axes(handles(6))
box on
xlabel('t (s)')
ylabel('x(t)')

% bouton de mise � jour
handles(7)=uicontrol('style','pushbutton',...
    'units','pixels',...
    'position',[300 10 200 20],...
    'string','Lire cn...',...
    'fontsize',12, ...
    'callback',@Ouvrir);
handles(8)=uicontrol('style','pushbutton',...
    'units','pixels',...
    'position',[510 10 200 20],...
    'string','Enregistrer cn...',...
    'fontsize',12, ...
    'callback',@Enregistrer);

end


function Rafraichir(obj,event)
global handles N xN fs f0

dat= get(handles(2),'data');

n = [-N:N];
cn = zeros(size(n));
cn(n>=0) = dat(:,1).*exp(1i*dat(:,2));
cn(n<=0) = flipud(dat(:,1).*exp(-1i*dat(:,2)));

f0 = str2num(get(handles(5),'String'));
T = 1/f0;

fs = 44100;
dt = 1/fs;
Nsig = round(2*fs);
t = [0:Nsig-1]*dt;

xN = zeros(size(t));

for k = 1:length(n)
    xN = xN + cn(k)*exp(j*2*pi*n(k)*t/T);
end

xN = real(xN);
xN = 0.95*xN/max(abs(xN));

axes(handles(6))
cla
hold on
plot(t,xN,'b-')
xlim([0 5*T])
ylim([-1 1])

end

function Ecouter(obj,event)
global handles N xN fs f0

sound(xN,fs)

end


function Enregistrer(obj,event)
global handles N xN fs f0

dat = get(handles(2),'data');

[FileName,PathName] = uiputfile('.txt');
save([PathName FileName],'dat','-ascii');

end

function Ouvrir(obj,event)
global handles N xN fs f0

[FileName,PathName] = uigetfile('.txt');
dat = load([PathName FileName],'-ascii');

set(handles(2),'data',dat);

Rafraichir
end


