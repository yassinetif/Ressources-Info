%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              %
%         EXERCISE 9b          %
%                              %
% Convolutions � temps continu %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;close all;clc

% -------------------------------------------------------------------------- %
% Les param�tres pour g�n�rer les r�ponses impulsionnelles � "temps continu" %
%                       (� ne pas modifier SVP)                              %
% -------------------------------------------------------------------------- %

Fe_over = 44100;
T_tot = 2^17/Fe_over;
N_over = fix(T_tot*Fe_over);
t_over = (0:N_over-1)/Fe_over;

disp('Vous devez choisir le param�tres suivants')
disp('------------------------------------------')
disp('|         alpha > 0                      |')
disp('|         F0 > 0                         |')
disp('------------------------------------------')
disp('')
disp('')

alpha2 = input('alpha2 = (alpha2 > 0) ');
while ( (alpha2<=0) )
    disp('|         alpha2 (alpha2 > 0)         |')
    alpha2 = input('alpha = (alpha > 0) ');
end
F0 = input('F0 = (F0 > 0) ');
while ( (F0<=0) )
    disp('|         F0 (F0 > 0)         |')
    F0 = input('F0 = (F0 > 0) ');
end

    % ----- %
    % hc(t) %
    % ----- %
    
%    Fc = 500; 
%	[B,A] = oct3dsgn(Fc,Fe_over); % 1/3 octave autour de 500Hz
%    hc = filter(B,A,[1 zeros(1,N_over-1)]);

    %F0 = 800;
    %alpha2 = 20*2*pi;
    hc = exp(-alpha2*t_over).*cos(2*pi*F0*t_over);
    
% ------------------------------------------------------------------ %
% Les param�tres pour g�n�rer les signaux d'entr�e � "temps continu" %
%                  (� ne pas modifier SVP)                           %
% ------------------------------------------------------------------ %

    % ----- %
    % xc(t) %
    % ----- %
    
    Fmin = 100;Fmax = 1000;
    alpha = (Fmax-Fmin)/(T_tot/2);beta = Fmin;
    xc = (cos(2*pi*(alpha*t_over(1:N_over)+beta*t_over(1:N_over).^2/2)+2*pi*rand(1)));%.*(tukeywin(N_over,0.01)).';

    
    xc = cos(2*pi*(Fmin+1/2*(Fmax-Fmin)*t_over/t_over(end)).*t_over+2*pi*rand(1));
    %xc=rand(size(xc));
% ---------------------------------- %
% les convolutions � "temps continu" %
% ---------------------------------- %

%yc = conv(xc,hc);
yc = (real(ifft(fft(xc).*fft(hc))));
yc = yc/Fe_over; % pour l'�quation aux dimensions

% f = (0:N_over-1)*Fe_over/N_over;
% figure(10)
% clf
% Xc = fft(xc);
% Hc = fft(hc);
% Yc = fft(yc);
% subplot(211)
% hold on
% plot(f(1:N_over/2+1),20*log10(abs(Xc(1:N_over/2+1))),'LineWidth',2)
% plot(f(1:N_over/2+1),20*log10(abs(Hc(1:N_over/2+1))),'r','LineWidth',2)
% %plot(f(1:N_over/2+1),20*log10(abs(Yc(1:N_over/2+1))),'k--','LineWidth',2)
% xlim([0 1200])
% grid on
% subplot(212)
% hold on
% plot(f(1:N_over/2+1),angle(Xc(1:N_over/2+1)),'LineWidth',2)
% plot(f(1:N_over/2+1),angle(Hc(1:N_over/2+1)),'r','LineWidth',2)
% %plot(f(1:N_over/2+1),angle(Yc(1:N_over/2+1)),'k--','LineWidth',1)
% xlim([0 1200])
% grid on

% ------- %
% figures %
% ------- %

figure(1)
subplot(311)
hold off
plot(t_over,xc,'b','LineWidth',2)
grid on
ylabel('x_c(t)')
axis([-0.001 T_tot 1.1*min(xc) 1.1*max(xc)])

subplot(312)
hold off
plot(t_over,hc,'b','LineWidth',2)
grid on
ylabel('h_2(t)')
axis([-0.001 T_tot 1.1*min(hc) 1.1*max(hc)])

subplot(313)
hold off
plot(t_over,yc,'k','LineWidth',2)
grid on
ylabel('y_c(t)')
axis([-0.001 T_tot 1.1*min(yc) 1.1*max(yc)])
%axis([-0.1 T_tot -0.1 1.1])

wavwrite(xc*0.95/max(abs(xc)),Fe_over,'exo9b_xc.wav')
wavwrite(yc*0.95/max(abs(yc)),Fe_over,'exo9b_yc.wav')

