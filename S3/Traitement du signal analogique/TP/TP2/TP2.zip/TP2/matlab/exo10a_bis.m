%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              %
%         EXERCISE 10a         %
%                              %
%   Syst�mes � temps continu   %
%                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;close all;clc

% -------------------------------------------------------------------------- %
% Les param�tres pour g�n�rer les r�ponses impulsionnelles � "temps continu" %
%                       (� ne pas modifier SVP)                              %
% -------------------------------------------------------------------------- %

disp('Vous devez choisir les param�tres suivants')
disp('------------------------------------------')
disp('|             N > 0  (dans le sujet N=3)                     |')
disp('|             t1 dans [1ms,1s]            |')
disp('|         alpha dans [0.001,0.99]         |')
disp('------------------------------------------')
disp('')
disp('')


N = input('N = (N > 0) ');
while ( N<=0 )
    disp('|             N > 0            |')
    N = input('N = (N > 0) ');
end


t1 = input('t1 = (dans [1ms,1s]) ');
while ( (t1<1e-3) | (t1>1))
    disp('|             t1 dans [1ms,1s]            |')
    t1 = input('t1 = (dans [1ms,1s]) ');
end

alpha = input('alpha = (dans [0.001,0.99]) ');
while ( (alpha<1e-3) | (alpha>0.99))
    disp('|         alpha dans [0.001,0.99]         |')
    alpha = input('alpha = (dans [0.001,0.99]) ');
end


Fe_over = 2*44100;
T_tot = 4;
N_over = fix(T_tot*Fe_over);
t_over = (0:N_over-1)/Fe_over;

fprintf('Choisissez un fichier son... ')

[FileName,PathName] = uigetfile('*.wav');

fprintf(FileName)
fprintf('\n\n')


[x Fe_over] = wavread([PathName FileName]);

x = x(:,1);
N_over = length(x);

td = 0.5; % valeur arbitraire



% ------------------------------ %
% r�ponse impulsionnelle directe %
% ------------------------------ %

% hdirecte = zeros(1,N_over);
% hdirecte(fix(td*Fe_over+1)) = 1;
% hdirecte(fix((td+t1)*Fe_over+1)) = alpha;

% --------------- %
% signal d'entr�e %
% --------------- %


t_over = (0:N_over-1)/Fe_over;

% ---------------- %
% signal de sortie %
% ---------------- %

% y = zeros(1,N_over);
% 
% y = (real(ifft(fft(x).*fft(hdirecte))));
% y = y;%/Fe_over; % pour l'�quation aux dimensions




%%

y = zeros(size(x));

ytd = zeros(size(y));
ytd(fix(td*Fe_over+1):length(y)) = x(1:length(y)-fix(td*Fe_over+1)+1);

ytdt1 = zeros(size(y));
ytdt1(fix((td+t1)*Fe_over+1):length(y)) = alpha*x(1:length(y)-fix((td+t1)*Fe_over+1)+1);

y = ytd+ytdt1;

% figure(2)
% clf
% subplot(411)
% plot(t_over,x)
% subplot(412)
% plot(t_over,ytd)
% subplot(413)
% plot(t_over,ytdt1)
% subplot(414)
% plot(t_over,y)


%%



% ------- %
% figures %
% ------- %

figure(1)
clf
subplot(311)
plot(t_over,x)
limy = ylim;
grid on
ylabel('x(t)')
subplot(312)
plot(t_over,y)
ylim(limy)
grid on
ylabel('y(t)')



%%

z = zeros(size(y));



for n = 0:N
yn = zeros(size(y));
yn(fix(n*t1*Fe_over+1):length(y)) = y(1:length(y)-fix(n*t1*Fe_over+1)+1);

z = z + (-1)^n*alpha^n*yn;

end

figure(1)
subplot(313)
cla
hold on
plot(t_over,z,'DisplayName','z(t)')
plot(t_over,z-ytd,'r-','DisplayName','z(t) - x(t-td)')
ylim(limy)
grid on
ylabel('z(t)')
legend toggle


wavwrite(0.95*y/max(abs(y)),Fe_over,['exo10a_' FileName(1:end-4) '_y.wav'])
wavwrite(0.95*z/max(abs(z)),Fe_over,['exo10a_' FileName(1:end-4) '_z.wav'])



