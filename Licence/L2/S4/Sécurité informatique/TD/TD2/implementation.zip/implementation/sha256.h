#ifndef SHA256_H
#define SHA256_H

/**************************** DATA TYPES ****************************/
typedef unsigned char BYTE; // 8-bit byte
typedef unsigned int  WORD; // 32-bit word, change to "long" for 16-bit machines

/*********************** FUNCTION DECLARATIONS **********************/
void sha256(const BYTE data[], size_t len, BYTE hash[]);

#endif   // SHA256_H
