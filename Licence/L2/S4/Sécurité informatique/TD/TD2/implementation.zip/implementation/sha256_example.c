#include <stdio.h>
#include <memory.h>
#include <string.h>
#include "sha256.h"

void print_hash(unsigned char hash[])
{
   int idx;
   for (idx=0; idx < 32; idx++)
      printf("%02x",hash[idx]);
   printf("\n");
}

int main()
{
   unsigned char text1[]={"01234567879"},
                 text2[]={"0123456787901234567879012345678790123456787901234567879"},
                 hash[32];
                 
   // Hash one
   sha256(text1, strlen(text1), hash);
   print_hash(hash);

   // Hash two
   sha256(text2, strlen(text2), hash);
   print_hash(hash);

   return 0;
}
