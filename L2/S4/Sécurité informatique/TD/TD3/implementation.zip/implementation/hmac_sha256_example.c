#include <stdio.h>
#include <string.h>

#include "hmac_sha256.h"

void print_hash(unsigned char hash[])
{
   int idx;
   for (idx=0; idx < 32; idx++)
      printf("%02x",hash[idx]);
   printf("\n");
}

int main()
{
	unsigned char text1[]={""},
                  text2[]={"The quick brown fox jumps over the lazy dog"},
                  hash[32];

   	// HMAC one
	hmac_sha256(text1, strlen(text1), "", 0, hash);
   	print_hash(hash);
                 
   	// HMAC two
	hmac_sha256(text2, strlen(text2), "key", 3, hash);
   	print_hash(hash);

   	return 0;
}
 