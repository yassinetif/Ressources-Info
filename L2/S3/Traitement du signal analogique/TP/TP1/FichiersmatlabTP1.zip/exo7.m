%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                 %
%                   EXERCISE 7                    %
%                                                 %
% Cosinus fen�tr� (rectangulaire, Hann, Bartlett) %
%                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%-----------------------------------------------------%
% TRAVAUX PRATIQUES DE LICENCE SPI (Semestre 3)
%
%                   ANNEE 2014-2015
%
% Auteurs : Fr�d�ric ABLITZER, Bruno BROUARD, 
% Bertrand LIHOREAU, Balbine MAILLOU, Laurent SIMON
%-----------------------------------------------------%

clear;close all;clc

% ------------------------------------------------------- %
% Les param�tres pour g�n�rer le signal � "temps continu" %
%         (� ne pas modifier SVP)                         %
% ------------------------------------------------------- %

A0 = 1;
F0 = 10;
phi0 = 0.45;

td = 0.2;
T = 1;

Fe_over = 100000;
N_over = fix(2*T*Fe_over);
t_over = (0:N_over-1)/Fe_over;

% --------------------------- %
% le signal � "temps continu" %
% --------------------------- %

xc = A0*cos(2*pi*F0*t_over+phi0);

% ------------------------------ %
% les fen�tres � "temps continu" %
% ------------------------------ %

w1 = zeros(1,N_over); % fen�tre rectangulaire
w2 = zeros(1,N_over); % fen�tre de Hann
w3 = zeros(1,N_over); % fen�tre de Bartlett (triangulaire)

ndeb = fix(td*Fe_over+1);
nfin = fix((td+T)*Fe_over);
N = fix(T*Fe_over);

w1(ndeb:nfin) = ones(1,N);  % fen�tre rectangulaire
w2(ndeb:nfin) = 0.5*(1-cos(2*pi*(t_over(1:N))/(T))); % Hann window
w3(ndeb:nfin) = (bartlett(N)).';

% ----------------------------------- %
% le signal fen�tr� � "temps continu" %
% ----------------------------------- %

xw1 = xc.*w1;
xw2 = xc.*w2;
xw3 = xc.*w3;

% ------- %
% figures %
% ------- %

figure(1)
hold off
plot(t_over,w1,'b','LineWidth',2)
hold on
plot(t_over,w2,'r','Linewidth',2)
plot(t_over,w3,'g','Linewidth',2)
grid on
axis([-0.1 (td+T)*1.1 -0.1 1.1])
xlabel('Time (s)');ylabel('Amplitude (lin)')
legend('Rect','Hann','Bartlett')

figure(2)
hold off
plot(t_over,xw1,'b','LineWidth',2)
hold on
plot(t_over,xw2,'r','Linewidth',2)
plot(t_over,xw3,'g','Linewidth',2)
grid on
axis([-0.1 (td+T)*1.1 -1.1 1.1])
xlabel('Time (s)');ylabel('Amplitude (lin)')
legend('Rect','Hann','Bartlett')

