%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               %
%          EXERCISE 2           %
%                               %
% Fen�tre rectangulaire d�cal�e %
%                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%-----------------------------------------------------%
% TRAVAUX PRATIQUES DE LICENCE SPI (Semestre 3)
%
%                   ANNEE 2014-2015
%
% Auteurs : Fr�d�ric ABLITZER, Bruno BROUARD, 
% Bertrand LIHOREAU, Balbine MAILLOU, Laurent SIMON
%-----------------------------------------------------%

clear;close all;clc

% ------------------------------------------------------- %
% Les param�tres pour g�n�rer le signal � "temps continu" %
%         (� ne pas modifier SVP)                         %
% ------------------------------------------------------- %

T = 2; % temps total
Fe_over = 100000;
N_over = fix(2*T*Fe_over);
t_over = (-N_over/2:N_over/2-1)/Fe_over;


disp('Vous devez choisir les param�tres dans les intervalles suivants ')
disp('----------------------------------------------------------------')
disp('|                         Tw dans [1ms,1s]                      |')
disp('|                          t0 dans [0,1s]                       |')
disp('----------------------------------------------------------------')
disp('')
disp('')

Tw = input('Tw = (en seconde) ');
while ( (Tw<0.001) | (Tw>5))
    disp('|                  Tw dans [1ms,1s]                   |')
    Tobs = input('Tw = (en seconde) ');
end

t0 = input('t0 = (en seconde) ');
while ( (t0<0) | (t0>1))
    disp('|                          t0 dans [0,1s]                       |')
    t0 = input('t0 = (en seconde) ');
end

% ---------------------------- %
% la fen�tre � "temps continu" %
% ---------------------------- %

w1 = zeros(1,N_over); % fen�tre rectangulaire

deb=find(t_over<t0-Tw/2);
ndeb=deb(end);
fin=find(t_over>t0+Tw/2);
nfin=fin(1);
w1(ndeb:nfin) =1;


% ------- %
% figures %
% ------- %

figure(1)
hold off
plot(t_over,w1,'b','LineWidth',2)
grid on
axis([-0.5+t0-Tw/2 t0+Tw/2+0.5 -0.1 1.1])
xlabel('Time (s)');ylabel('Amplitude (lin)')
