%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                 %
%                   EXERCISE 8                    %
%                                                 %
%    EXERCICE DE SYNTHESE SUR SIGNAUX TEMPORELS   %
%                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%-----------------------------------------------------%
% TRAVAUX PRATIQUES DE LICENCE SPI (Semestre 3)
%
%                   ANNEE 2014-2015
%
% Auteurs : Fr�d�ric ABLITZER, Bruno BROUARD, 
% Bertrand LIHOREAU, Balbine MAILLOU, Laurent SIMON
%-----------------------------------------------------%

clear;close all;clc

% ------------------------------------------------------- %
% Les param�tres pour g�n�rer le signal � "temps continu" %
%         (� ne pas modifier SVP)                         %
% ------------------------------------------------------- %

A1 = 0.8;
F1 = 1000;
phi1 = 2*pi*rand(1);

T = 4; % temps total
Fe_over = 2*44100;Te_over = 1/Fe_over;
N_over = fix(T*Fe_over);
t_over = (0:N_over-1)/Fe_over;

% ----------------------------------- %
% le signal de base � "temps continu" %
% ----------------------------------- %

xc = A1*cos(2*pi*F1*t_over+phi1);
yc = zeros(1,N_over);


% Pour chacune des 4 s
% on choisit
% --------------------
% 1. de ne rien faire
% 2. de fenetrer avec une rampe + ou - le signal sur la duree de son support
% 3. de moduler l'amplitude de mani�re sinusoidale (frequence 5 Hz)
% 4. 

Nseq = N_over/4;
Fmod = 10;
Coefmod = 0.33;
A2 = 0.15;
A3 = 0.25;
A4 = 0.15;
phi2 = 2*pi*rand(1);
phi3 = 2*pi*rand(1);
phi4 = 2*pi*rand(1);

for k = 1:4
    
    deb = (k-1)*Nseq+1;
    fin = k*Nseq;
    
    disp(['Sequence ' num2str(k)]);
    
    R = input('Operation ? [Aucune/rampe Positive/rampe Negative/Modulation/ajout Harmoniques]');
    
    while((R~='A')&(R~='P')&(R~='N')&(R~='M')&(R~='H'))
        disp('R = [N/F/M/A] !')
        R = input('Operation ? [Aucune/rampe Positive/rampe Negative/Modulation/ajout Harmoniques] ?');
    end
    
    if (R=='A')
        yc(deb:fin) = xc(deb:fin);
    elseif (R=='P')
        wtmp = ((deb:fin)-deb)/(fin-deb);
        yc(deb:fin) = xc(deb:fin).*wtmp;
    elseif (R=='N')
        wtmp = (fin-(deb:fin))/(fin-deb);
        yc(deb:fin) = xc(deb:fin).*wtmp;
    elseif (R=='M')
        ampmod = cos(2*pi*Fmod*(0:fin-deb)*Te_over);
        yc(deb:fin) = xc(deb:fin).*(1+Coefmod*ampmod);
    elseif (R=='H')
        yc(deb:fin) = xc(deb:fin)+A2*cos(2*pi*2*F1*t_over(deb:fin)+phi2)+A3*cos(2*pi*3*F1*t_over(deb:fin)+phi3)+A4*cos(2*pi*4*F1*t_over(deb:fin)+phi4);

    end
    
end

% ------- %
% figures %
% ------- %

figure(1)
hold off
plot(t_over,yc,'b','LineWidth',2)
grid on

y = 0.95*yc/max(yc);
wavwrite(y,44100,'essai.wav')
