%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               %
%          EXERCISE 4           %
%                               %
%          Battements           %
%                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%-----------------------------------------------------%
% TRAVAUX PRATIQUES DE LICENCE SPI (Semestre 3)
%
%                   ANNEE 2014-2015
%
% Auteurs : Fr�d�ric ABLITZER, Bruno BROUARD, 
% Bertrand LIHOREAU, Balbine MAILLOU, Laurent SIMON
%-----------------------------------------------------%

clear;close all;clc

% ------------------------------------------------------- %
% Les param�tres pour g�n�rer le signal � "temps continu" %
%         (� ne pas modifier SVP)                         %
% ------------------------------------------------------- %

T = 2; % temps total
Fe_over = 44100*2;
N_over = fix(T*Fe_over);
t_over = (0:N_over-1)/Fe_over;

F0 = 1000;
A0 = 1;
phi0 = 2*pi*rand(1);
phi1 = 2*pi*rand(1);


disp('Vous devez choisir les param�tres dans les intervalles suivants ')
disp('----------------------------------------------------------------')
disp('|                         F1 dans [950,1050]Hz                   |')
disp('----------------------------------------------------------------')
disp('')
disp('')

F1 = input('F1 = (en Hz) ');
while ( (F1<950) | (F1>1050))
    disp('|                         F1 dans [950,1050]Hz                   |')
    F1 = input('F1 = (en Hz) ');
end


% ----------------------------- %
% les signaux � "temps continu" %
% ----------------------------- %

x1 = sin(2*pi*F0*t_over+phi0);
x2 = sin(2*pi*F1*t_over+phi1);
x = x1+x2;

%x = 0.95*x/max(x);

wavwrite(x,Fe_over,'battements.wav')

% ------- %
% figures %
% ------- %

figure(1)
plot(t_over,x,'b','LineWidth',2)
grid on
axis([0 1 -2 2])
xlabel('Time (s)');ylabel('Amplitude (lin)')
