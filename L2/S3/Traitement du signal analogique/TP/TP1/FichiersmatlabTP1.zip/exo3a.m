%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                    %
%            EXERCICE 3a             %
%                                    %
% Exponentielle d�croissante causale %
%                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%-----------------------------------------------------%
% TRAVAUX PRATIQUES DE LICENCE SPI (Semestre 3)
%
%                   ANNEE 2014-2015
%
% Auteurs : Fr�d�ric ABLITZER, Bruno BROUARD, 
% Bertrand LIHOREAU, Balbine MAILLOU, Laurent SIMON
%-----------------------------------------------------%

clear;close all;clc

% ------------------------------------------------------- %
% Les param�tres pour g�n�rer le signal � "temps continu" %
%         (� ne pas modifier SVP)                         %
% ------------------------------------------------------- %

Fe_over = 2*44100; % fr�quence de sur-�chantillonnage

% ---------------------------------------------------------- %


disp('Vous devez choisir le param�tre dans l''intervalle suivant ')
disp('-----------------------------------------------------------')
disp('|                  alpha dans [1e-3,1e3]                   |')
disp('-----------------------------------------------------------')
disp('')
disp('')

alpha = input('alpha = (en 1/seconde) ');
while ( (alpha<1e-3) | (alpha>1e3))
    disp('           alpha dans [1e-3,1e3]            ')
    alpha = input('alpha = (en 1/seconde) ');
end

Tobs = (log(100))/alpha; % temps d'observation (pour avoir exp(-alpha Tobs) = 0.01)
N_over = fix(Tobs*Fe_over); % nombre max de points
t_over = (-N_over:N_over-1)/Fe_over; % dur�e max d'observation

% --------------------------- %
% le signal � "temps continu" %
% --------------------------- %

xc = [zeros(1,N_over) exp(-alpha*t_over(N_over+1:2*N_over))];

wavwrite(xc*0.95,Fe_over,'expdec.wav')

% ------- %
% figures %
% ------- %

figure(1)
hold off
plot(t_over,xc,'b','LineWidth',2)
grid on
axis([-Tobs/10 Tobs -0.1 1.1])
xlabel('Time (s)');ylabel('Amplitude (lin)')
