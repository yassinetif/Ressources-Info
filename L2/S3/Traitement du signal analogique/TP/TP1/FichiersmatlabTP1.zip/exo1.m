%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                        %
%               EXERCICE 1               %
%                                        %
% Visualisation de signaux � TC COS/SIN  %
%                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%-----------------------------------------------------%
% TRAVAUX PRATIQUES DE LICENCE SPI (Semestre 3)
%
%                   ANNEE 2014-2015
%
% Auteurs : Fr�d�ric ABLITZER, Bruno BROUARD, 
% Bertrand LIHOREAU, Balbine MAILLOU, Laurent SIMON
%-----------------------------------------------------%


clear;close all;clc

disp('Vous devez choisir les param�tres dans les intervalles suivants ')
disp('----------------------------------------------------------------')
disp('|                  Tobservation dans [1ms,5s]                   |')
disp('|                      T0=1/F0 dans [1ms,1s]                    |')
disp('|                         A0 dans [0.1,10]                      |')
disp('|                         phi0 dans [0,2pi]                     |')
disp('----------------------------------------------------------------')
disp('')
disp('')


Tobs = input('Tobservation = (en seconde) ');
while ( (Tobs<0.001) | (Tobs>5))
    disp('|                  Tobservation dans [1ms,5s]                   |')
    Tobs = input('Tobservation = (en seconde) ');
end

T0 = input('T0 = (en seconde) ');
while ( (T0<0.001) | (T0>1))
    disp('|                      T0=1/F0 dans [1ms,1s]                    |')
    T0 = input('T0 = (en seconde) ');
end

F0 = 1/T0;

A0 = input('A0 = ');
while ( (A0<0.1) | (A0>10))
    disp('|                         A0 dans [0.1,10]                      |')
    A0 = input('A0 = ');
end

phi0 = input('phi0 = (radian) ');

% ------------------------------------------------------- %
% Les param�tres pour g�n�rer le signal � "temps continu" %
%         (� ne pas modifier SVP)                         %
% ------------------------------------------------------- %

Fe_over = 100000; % fr�quence de sur-�chantillonnage
N_over = 5*Fe_over; % nombre max de points
t_over = (0:N_over-1)/Fe_over; % dur�e max d'observation

% --------------------------- %
% le signal � "temps continu" %
% --------------------------- %

xc = A0*cos(2*pi*F0*t_over+phi0);

% ------- %
% figures %
% ------- %

figure(1)
plot(t_over,xc,'b','LineWidth',2)
grid on
axis([0 Tobs -A0*1.1 A0*1.1])
xlabel('Time (s)');ylabel('Amplitude (lin)')
