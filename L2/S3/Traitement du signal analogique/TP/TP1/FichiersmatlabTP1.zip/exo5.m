%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                               %
%          EXERCISE 5           %
%                               %
%          Battements           %
%                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%-----------------------------------------------------%
% TRAVAUX PRATIQUES DE LICENCE SPI (Semestre 3)
%
%                   ANNEE 2014-2015
%
% Auteurs : Fr�d�ric ABLITZER, Bruno BROUARD, 
% Bertrand LIHOREAU, Balbine MAILLOU, Laurent SIMON
%-----------------------------------------------------%

clear;close all;clc

% ------------------------------------------------------- %
% Les param�tres pour g�n�rer le signal � "temps continu" %
%         (� ne pas modifier SVP)                         %
% ------------------------------------------------------- %

T = 2; % temps total
Fe_over = 44100*2;
N_over = fix(T*Fe_over);
t_over = (0:N_over-1)/Fe_over;

F0 = 2000;
A0 = 1;
phi0 = 2*pi*rand(1);
alpha0 = F0/20;

attenuation = 0.8;

disp('Vous devez choisir les param�tres dans les intervalles suivants ')
disp('----------------------------------------------------------------')
disp('|                      Delta_t dans [0,1]s                   |')
disp('----------------------------------------------------------------')
disp('')
disp('')

Delta_t = input('Delta_t = (en s) ');
while ( (Delta_t<0) | (Delta_t>1))
    disp('|                      Delta_t dans [0,1]s                   |')
    Delta_t = input('Delta_t = (en s) ');
end

N_Delta_t = fix(Delta_t*Fe_over);

% --------------------------- %
% le signal � "temps continu" %
% --------------------------- %

x = zeros(1,N_over);
x = (cos(2*pi*F0*t_over+phi0)).*exp(-alpha0*t_over);
x(N_Delta_t+1:N_over) = x(N_Delta_t+1:N_over) + attenuation*x(1:N_over-N_Delta_t);

x = 0.95*x/max(x);

wavwrite(x,Fe_over,'echo.wav')

% ------- %
% figures %
% ------- %

figure(1)
plot(t_over,x,'b','LineWidth',2)
grid on
axis([0 1 -1 1])
xlabel('Time (s)');ylabel('Amplitude (lin)')
