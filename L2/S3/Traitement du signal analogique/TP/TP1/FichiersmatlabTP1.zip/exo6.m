%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                        %
%                      EXERCICE 6                        %
%                                                        %
% Visualisation de signaux � TC COS/SIN fen�tr� par RECT %
%                                                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%-----------------------------------------------------%
% TRAVAUX PRATIQUES DE LICENCE SPI (Semestre 3)
%
%                   ANNEE 2014-2015
%
% Auteurs : Fr�d�ric ABLITZER, Bruno BROUARD, 
% Bertrand LIHOREAU, Balbine MAILLOU, Laurent SIMON
%-----------------------------------------------------%

clear;close all;clc

disp('Vous devez choisir les param�tres dans les intervalles suivants ')
disp('----------------------------------------------------------------')
disp('|                      Tw dans [1ms,5s]                         |')
disp('|                          t0 dans [0,1s]                       |')
disp('|                      T0=1/F0 dans [1ms,1s]                    |')
disp('|                         A0 dans [0.1,10]                      |')
disp('|                         phi0 dans [0,2pi]                     |')
disp('----------------------------------------------------------------')
disp('')
disp('')


Tw = input('Tw = (en seconde) ');
while ( (Tw<0.001) | (Tw>5))
    disp('|                  Tw dans [1ms,5s]                   |')
    Tw = input('Tw = (en seconde) ');
end

t0 = input('t0 = (en seconde) ');
while ( (t0<0) | (t0>1))
    disp('|                          t0 dans [0,1s]                       |')
    t0 = input('t0 = (en seconde) ');
end

T0 = input('T0 = (en seconde) ');
while ( (T0<0.001) | (T0>1))
    disp('|                      T0=1/F0 dans [1ms,1s]                    |')
    T0 = input('T0 = (en seconde) ');
end

F0 = 1/T0;

A0 = input('A0 = ');
while ( (A0<0.1) | (A0>10))
    disp('|                         A0 dans [0.1,10]                      |')
    A0 = input('A0 = ');
end

phi0 = input('phi0 = (radian) ');


% ------------------------------------------------------- %
% Les param�tres pour g�n�rer le signal � "temps continu" %
%         (� ne pas modifier SVP)                         %
% ------------------------------------------------------- %

Fe_over = 100000; % fr�quence de sur-�chantillonnage
N_over = 5*Fe_over; % nombre max de points
t_over = (-N_over/2:N_over/2-1)/Fe_over;
% --------------------------- %
% le signal � "temps continu" %
% --------------------------- %

xc = zeros(1,N_over);

deb=find(t_over<t0-Tw/2);
ndeb=deb(end);
fin=find(t_over>t0+Tw/2);
nfin=fin(1);

xc(ndeb:nfin)=A0*cos(2*pi*F0*t_over(ndeb:nfin)+phi0);

% ------- %
% figures %
% ------- %

figure(1)
plot(t_over,xc,'b','LineWidth',2)
grid on
axis([-0.5+t0-Tw/2 t0+Tw/2+0.5 -A0*1.1 A0*1.1])
xlabel('Time (s)');ylabel('Amplitude (lin)')
