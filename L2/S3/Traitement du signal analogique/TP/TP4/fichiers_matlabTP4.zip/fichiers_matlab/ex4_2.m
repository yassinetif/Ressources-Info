%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% IDENTIFICATION SYSTEME
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function ex4_2

close all
clear all
clc

global parametres xWin hWin yWin XWin HWin YWin xLoaded flim bouton_play


COLOR1 = [0.52 0.75 1];
COLOR2 = [0.52 0.75 1];
COLOR3 = [1 0 0];

xLoaded = false;

figure(1)
set(gcf,...
   'Units','pixels',...
   'Position',[50 50 800 650],...
   'Resize','off',...
   'ToolBar','figure',...
   'color',COLOR1,...
   'numbertitle','off',...
   'name','L2 SPI - TP Traitement du signal'...
   );



xWin = axes(...
   'Units','pixels',...
   'Position',[50 500 300 130],...
   'Box','on'...
   );

XWin = axes(...
   'Units','pixels',...
   'Position',[450 500 300 130],...
   'Box','on'...
   );


yWin = axes(...
   'Units','pixels',...
   'Position',[50 320 300 130],...
   'Box','on'...
   );


YWin = axes(...
   'Units','pixels',...
   'Position',[450 320 300 130],...
   'Box','on'...
   );

% hWin = axes(...
%     'Units','pixels',...
%     'Position',[50 140 300 130],...
%     'Box','on'...
%     );

HWin = axes(...
   'Units','pixels',...
   'Position',[450 140 300 130],...
   'Box','on'...
   );





bouton_new = uicontrol('Style', 'pushbutton', 'String', 'Charger x(t)',...
   'Position', [20 50 300 20],...
   'Callback', @LoadSignals);

bouton_play(1) = uicontrol('Style', 'pushbutton', 'String', 'PLAY x(t)',...
   'Position', [20 20 100 20],...
   'Callback', @PlaySignal);
% % bouton_play(2) = uicontrol('Style', 'pushbutton', 'String', 'PLAY h(t)',...
% %     'Position', [130 20 100 20],...
% %     'Callback', @PlaySignal);
bouton_play(3) = uicontrol('Style', 'pushbutton', 'String', 'PLAY x(t)*h(t)',...
   'Position', [240 20 150 20],...
   'Callback', @PlaySignal);


flim = [0 5000];

axes(xWin)
xlabel('t (s)')
ylabel('x (t)')

axes(XWin)
ylabel('|X| (dB)')
xlabel('f (Hz)')
xlim(flim)

% axes(hWin)
% xlabel('t (s)')
% ylabel('h (t)')

axes(HWin)
ylabel('|H| (dB)')
xlabel('f (Hz)')
xlim(flim)

axes(yWin)
xlabel('t (s)')
ylabel('y (t)')

axes(YWin)
ylabel('|Y| (dB)')
xlabel('f (Hz)')
xlim(flim)

MaJ(0,0)

end




function MaJ(obj,event)

global parametres xWin hWin yWin XWin HWin YWin xLoaded flim
global t x Freq X h N Nfft Fe y  x_bruite y_bruite

alpha = 200*2*pi;

if obj==1 % ne refaire les calculs que si on change T



   %     % Definition du signal %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %
   %     Fe = 44100;
   %     dt = 1/Fe;
   %
   %     if ~xLoaded % si le x n'a pas encore ete charge
   %         t = [0:1:fix(0.05/dt)]*dt;
   %         Nfft = pow2(nextpow2(length(t)));
   %         t = t(:);
   %     end
   %
   %
   %




h = zeros(size(t));

h(t<0) = 0;
h(t>=0) = exp(-alpha*(t(t>=0)));


H = fft(h,Nfft);

x_bruite = real(ifft(X));

coeff_bruit = 0.01*max(abs(x_bruite));

x_bruite = x_bruite + randn(size(x_bruite))*coeff_bruit;
X_bruite = fft(x_bruite);




Y = X_bruite.*H;

y_bruite = real(ifft(Y));
y_bruite = y_bruite + randn(size(y_bruite))*coeff_bruit;
Y_bruite = fft(y_bruite);


H_ident = Y_bruite./X_bruite;
h_ident = real(ifft(H_ident));
h_ident = h_ident(1:N);




axes(xWin)
plot(t,x_bruite(1:N),'Linewidth',2)
xlabel('t (s)')
ylabel('x(t)')
xlim([0 t(end)])

axes(XWin)
plot([0:Nfft-1]/Nfft*Fe,20*log10(abs(X_bruite)),'Linewidth',2)
ylabel('|X| (dB)')
xlabel('f (Hz)')
xlim(flim)
set(gca,'XScale','log')

axes(yWin)
plot(t,y_bruite(1:N),'Linewidth',2)
xlabel('t (s)')
ylabel('y(t)')
xlim([0 t(end)])

axes(YWin)
plot([0:Nfft-1]/Nfft*Fe,20*log10(abs(Y_bruite)),'Linewidth',2)
ylabel('|Y| (dB)')
xlabel('f (Hz)')
xlim(flim)
set(gca,'XScale','log')



%     axes(hWin)
%     cla
%     hold on
%     plot(t,h_ident,'Linewidth',2)
%     plot(t,h,'k--','Linewidth',2)
%     xlabel('t (s)')
%     ylabel('h (t)')
%     xlim([0 0.05])


axes(HWin)
cla
hold on
plot([0:Nfft-1]/Nfft*Fe,20*log10(abs(H_ident)),'Linewidth',2)
plot([0:Nfft-1]/Nfft*Fe,20*log10(abs(H)),'g--','Linewidth',2)

ylabel('|H| (dB)')
xlabel('f (Hz)')
set(gca,'XScale','log')
xlim(flim)


end

end





function LoadSignals(obj,event)


global parametres xWin hWin yWin XWin HWin YWin xLoaded
global t x Freq X h N Nfft Fe

[FileName,PathName] = uigetfile('*.wav','Choisir le signal x(t)');
[x Fe] = wavread([PathName FileName]);
x = x(:,1);
dt = 1/Fe;

N = length(x);
t = [0:N-1]*dt;
t = t(:);


Nfft = pow2(nextpow2(N));

X = fft(x,Nfft);


xLoaded = true;


MaJ(1,1)

end






function PlaySignal(obj,event)

global parametres xWin hWin yWin XWin HWin YWin xLoaded bouton_play
global t x Freq X h N Nfft Fe y x_bruite y_bruite


switch obj
   case bouton_play(1)
       if xLoaded
           sound(x_bruite(1:N)/max(abs(x_bruite)),Fe);
       end
       %     case bouton_play(2)
       %         sound(h/max(abs(h)),Fe);
   case bouton_play(3)
       if xLoaded
           sound(y_bruite(1:N)/max(abs(y_bruite)),Fe);
       end
end

end