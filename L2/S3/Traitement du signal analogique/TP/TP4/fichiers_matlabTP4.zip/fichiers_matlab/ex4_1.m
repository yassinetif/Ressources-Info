%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% APPLET
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function applet

close all
clear
clc

global parametres xWin xZoomWin XWin Nom
global t x Fe xLoaded

COLOR1 = [0.52 0.75 1];
COLOR2 = [0.52 0.75 1];
COLOR3 = [1 0 0];

xLoaded = false;

figure(1)
set(gcf,...
    'Units','pixels',...
    'Position',[50 50 1000 600],...
    'Resize','off',...
    'ToolBar','figure',...
    'color',COLOR1,...
    'numbertitle','off',...
    'name','L2 SPI - TP Traitement du signal'...
    );

Nom = uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[50 550 800 25],...
    'string','',...
    'fontsize',16,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);

xWin = axes(...
    'Units','pixels',...
    'Position',[50 400 400 140],...
    'Box','on'...
    );

xZoomWin = axes(...
    'Units','pixels',...
    'Position',[50 150 400 140],...
    'Box','on'...
    );

XWin = axes(...
    'Units','pixels',...
    'Position',[550 200 400 300],...
    'Box','on'...
    );



uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[50 340 50 20],...
    'string','t1 = ',...
    'fontsize',10,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);
parametres(1)=uicontrol('style','edit' , ...
    'units','pixels', ...
    'position',[100 340 80 20],...
    'string','0.2',...
    'fontsize',10,...
    'backgroundcolor',[1 1 1],...
    'CallBack',@MaJ);

uicontrol('style','text' , ...
    'units','pixels', ...
    'position',[320 340 50 20],...
    'string','t2 = ',...
    'fontsize',10,...
    'HorizontalAlignment','left',...
    'backgroundcolor',COLOR2);
parametres(2)=uicontrol('style','edit' , ...
    'units','pixels', ...
    'position',[370 340 80 20],...
    'string','0.3',...
    'fontsize',10,...
    'backgroundcolor',[1 1 1],...
    'CallBack',@MaJ);


boutonCharger = uicontrol('Style', 'pushbutton', 'String', 'Charger x(t)...',...
    'Position', [50 50 200 20],...
    'Callback', @LoadSignal);

boutonEcouter = uicontrol('Style', 'pushbutton', 'String', 'Écouter x(t)',...
    'Position', [300 50 200 20],...
    'Callback', @Play_x);

boutonEcouter = uicontrol('Style', 'pushbutton', 'String', 'Écouter l''extrait',...
    'Position', [550 50 200 20],...
    'Callback', @Play_x_select);



axes(xWin)
xlabel('t (s)')
ylabel('x (t)')

axes(xZoomWin)
xlabel('t (s)')
ylabel('x (t)')

axes(XWin)
ylabel('|X| (dB)')
xlabel('f (kHz)')


%MaJ(1,1)

end










function MaJ(obj,event)

global parametres xWin xZoomWin XWin
global t x x_select Fe xLoaded




t1 = str2num(get(parametres(1),'string'));
t2 = str2num(get(parametres(2),'string'));

if xLoaded
    
    axes(xWin)
    cla
    hold on
    plot(t,x,'Color',0.5*[1 1 1])
    xlim([0 t(end)])
    xlabel('t (s)')
    ylabel('x (t)')
    grid on
    
    select = t>=t1 & t<=t2;
    
    t_select = t(select);
    x_select = x(select);
    
    
    
    axes(xWin)
    plot(t_select,x_select,'Color','b')
    
    
    axes(xZoomWin)
    plot(t_select,x_select)
    xlim(t_select([1 end]))
    xlabel('t (s)')
    ylabel('x (t)')
    
    grid on
    
    
    Nfft = pow2(2+nextpow2(length(t)));
    
    X = fft(x_select,Nfft);
    
    
    f = [0:Nfft-1]/Nfft*Fe;
    
    
    axes(XWin)
    plot(f,20*log10(abs(X)))
    xlim([0 1E4])
    ylabel('|X| (dB)')
    xlabel('f (Hz)')
    grid on
    
end




end





function LoadSignal(obj,event)

global parametres xWin xZoomWin XWin Nom
global t x Fe xLoaded

[FileName,PathName] = uigetfile('*.wav','Choisir le signal x(t)');
[x Fe] = wavread([PathName FileName]);
x = x(:,1);
dt = 1/Fe;

N = length(x);
t = [0:N-1]*dt;
t = t(:);

xLoaded = true;



set(parametres(1),'string','0')
set(parametres(2),'string',fix(round(t(end)*10)/10))

set(Nom,'string',FileName)

MaJ(1,1)

end






function Play_x(obj,event)

global t x x_select Fe xLoaded

if xLoaded
    
    sound(x/max(abs(x)),Fe);
    
end

end

function Play_x_select(obj,event)

global t x x_select Fe xLoaded

if xLoaded
    
    sound(x_select/max(abs(x_select)),Fe);
    
end

end






